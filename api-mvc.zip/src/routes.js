import { Router } from 'express';
import logMid from './app/middlewares/logRequests';
import growdeverController from './app/controllers/growdeverController';

const routes = new Router();

routes.use(logMid);

routes.get('/', (req, res) => {
    res.send('Rota principal');
});

routes.get('/growdevers', growdeverController.index);
routes.get('/growdevers/:id', growdeverController.show);
routes.post('/growdevers', growdeverController.store);
routes.put('/growdevers/:id', growdeverController.update);
routes.delete('/growdevers/:id', growdeverController.delete);

export default routes;